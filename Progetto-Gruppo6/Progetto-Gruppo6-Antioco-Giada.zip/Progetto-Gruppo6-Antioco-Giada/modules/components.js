{/*
<div class="card">
    <img class="card__img" src="https://picsum.photos/200/200?grayscale
    " alt="pippo">
    <h3 class="card__title">Nome Artista</h3>
    <span class="card__id"># id</span>
    <p class="card__type">Type: genere</p>
</div>  
*/}

const cardElGen = (obj) => {
    console.log(obj)
    const cardEl = document.createElement('div');
    const imgEl = document.createElement('img');
    const titleEl = document.createElement('h3');
    const idEl = document.createElement('span');
    const typeEl = document.createElement('p');

    cardEl.className = 'card';    
    cardEl.classList.add('card', obj.type)

    imgEl.src = obj.image;
    imgEl.className = 'card__img'
    imgEl.alt = obj.name;
    
    titleEl.className = 'card__title'
    titleEl.textContent = ` # ${obj.name}`;
    
    idEl.className = 'card__id'
    idEl.textContent = obj.id;
    
    idEl.className = 'card__type'
    idEl.textContent = obj.type;

    cardEl.append(imgEl, titleEl, idEl, typeEl)
    return cardEl
}

const cardListGen = () => {
    const cardEl = document.createElement('div');

    cardEl.className = 'card-list'

    return cardEl;
}

export {
    cardElGen,
    cardListGen
}